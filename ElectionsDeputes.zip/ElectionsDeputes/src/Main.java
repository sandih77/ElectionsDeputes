package main;

import gui.FenetreResultat;

public class Main {

    public static void main(String[] args) {
        new FenetreResultat().setVisible(true);
    }
}
